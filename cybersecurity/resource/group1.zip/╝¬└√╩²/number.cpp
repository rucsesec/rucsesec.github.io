#include <cstdio>
#include <iostream>

using namespace std;

typedef long long LL;

LL n;
const LL p =1e9+7;

LL pow(LL a,LL b,LL p){
	LL ret = 1 % p;
	while(b){
		if(b&1) ret=(ret*a)%p;
		b>>=1;
		a=(a*a)%p;
	}
	return ret;
}
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>n;
	cout<< ((((1+pow(5,n,p)+2*pow(3,n+1,p))%p * pow(4,p-2,p) % p ) - pow(2,n,p) -pow(4,n,p))%p+p)%p <<endl;
	fclose(stdout);
	return 0;
}
