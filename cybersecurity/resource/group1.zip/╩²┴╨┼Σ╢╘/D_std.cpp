#include<bits/stdc++.h>
using namespace std;
int n,k;
int A[100005],B[100005];
int main()
{
    freopen("D(6).in","r",stdin);
    freopen("D(6).out","w",stdout);
    cin >> n >> k;
    for(int i = 1; i <= n; i++) cin >> A[i];
    for(int i = 1; i <= n; i++) cin >> B[i];
    sort(A+1,A+n+1);
    sort(B+1,B+n+1);
    int maxnum = 0,j = n;
    for(int i = n; i >= 1; i --){
        while(j > 0 && B[j]>A[i]) j--;
        if(j>0&&A[i]>=B[j]){
            maxnum++;
            j--;
        }
    }
    //cout << maxnum << endl;
    if(maxnum>=k){
        puts("YES");
    }
    else{
        puts("NO");
    }

}