#include<bits/stdc++.h>
#define random(a,b) a + rand()%(b-a+1)
using namespace std;
int C[100005],D[100005];
int main(){
    freopen("D(10).in","w",stdout);
    srand(time(NULL));
    int n,k;
    n = 100000;
    for(int i = 1; i <= n; i++) C[i] = random(1,n*10);
    for(int i = 1; i <= n; i++) D[i] = random(1,n*10);
    cout << n << " " << random(0,n) << endl;
    for(int i = 1; i <= n; i++) cout << C[i] << " ";
    cout << endl;
    for(int i = 1; i <= n; i++) cout << D[i] << " ";
    cout << endl;
}