#include <iostream>
#include <algorithm>
#include <cstdio>
#define N 500020
using namespace std;

int f[N];

int main(void) // mid.cpp
{
    int t, n, k, x;
    int i, s;
    bool a, b;

    freopen("mid.in" , "r", stdin );
    freopen("mid.out", "w", stdout);

    scanf("%d", &t);
    while(t --)
    {
        scanf("%d %d", &n, &k);
        a = b = false;
        for(i = 1, s = N; i <= n; i ++)
        {
            scanf("%d", &x);
            a |= x == k;

            f[i] = f[i - 1] + (x < k ? -1 : 1);
            if(i > 1)
            {
                s = min(s, f[i - 2]);
                b |= f[i] > s;
            }
        }
        printf("%s\n", a && (b || n == 1) ? "Yes" : "No");
    }

    return 0;
}
