#include<bits/stdc++.h>
using namespace std;
int A[11];
int main()
{
    freopen("A(10).in","r",stdin);
    freopen("A(10).out","w",stdout);
    for(int i = 0; i < 10; i++) cin >> A[i];
    int minnum = 0;
    for(int i = 9 ; i > 0; i--) if(A[i]) minnum = i;
    A[minnum]--;
    cout<<minnum;
    for(int i = 0; i <= 9; i++)
        for(int j = 1; j <= A[i]; j++)
            cout << i;
}