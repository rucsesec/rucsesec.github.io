#include<bits/stdc++.h>
#define random(a,b) a + rand()%(b-a+1)
using namespace std;
int main(){
    freopen("A(10).in","w",stdout);
    srand(time(NULL));
    for(int i = 1; i <= 10; i++) cout << random(0,10) << " ";
}