#include<cmath>
#include<queue>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define fi first
#define se second
using namespace std;
typedef long long ll;
const int N=1e6+5;
inline int read(){
    int X=0,w=0;char ch=0;
    while(!isdigit(ch)){w|=ch=='-';ch=getchar();}
    while(isdigit(ch))X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}

int a[N];
struct node{
	int x,y,v;
	node(){}
	node(int _x,int _y,int _v){
		x=_x;y=_y;v=_v;
	}
	bool operator <(const node &b) const{
		return v<b.v;
	}
}x[N];
bool in(int i1,int i2,int i3,int i4){
	if(i1==i3)return 1;
	if(i1==i4)return 1;
	if(i2==i3)return 1;
	if(i2==i4)return 1;
	return 0;
}
int main(){
	int n;
	while(scanf("%d",&n)!=EOF) {
		if(!n) return 0;
		for(int i=1;i<=n;i++){
			a[i]=read();
		}
		sort(a+1,a+n+1);
		int cnt=0;
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				x[++cnt]=node(i,j,a[i]+a[j]);
			}
		}
		sort(x+1,x+cnt+1);
		bool flag=0;
		for(int i=n;!flag&&i>=1;i--){
			for(int j=n;!flag&&j>=1;j--){
				if(i==j)continue;
				int l=1,r=cnt;
				while(l<r){
					int mid=(l+r)>>1;
					if(x[mid].v<a[i]-a[j])l=mid+1;
					else r=mid;
				}
				if(x[l].v!=a[i]-a[j])continue;
				for(int k=l;!flag&&k<cnt;k++){
					if(x[k].v!=x[l].v)break;
					if(!in(x[k].x,x[k].y,i,j)){
						cout<<a[i]<<endl;
						flag=1;
					}
				}
			}
		}
		if(!flag)puts("no solution");
	}
}